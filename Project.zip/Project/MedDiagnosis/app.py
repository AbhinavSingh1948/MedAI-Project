"""
=============================================================
 Disease Detection & Medical Diagnosis Support System
 app.py  –  Streamlit Frontend Application
=============================================================
 Run with:  streamlit run app.py
=============================================================
"""

import os
import warnings
import datetime
import numpy as np
import pandas as pd
import joblib
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────────
# PAGE CONFIG  (must be first Streamlit call)
# ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title  = "MedAI — Disease Detection System",
    page_icon   = "🩺",
    layout      = "wide",
    initial_sidebar_state = "expanded",
)

# ─────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR   = os.path.join(BASE_DIR, "models")
SCALER_DIR  = os.path.join(MODEL_DIR, "scalers")
DATA_DIR    = os.path.join(BASE_DIR, "datasets")
HISTORY_DIR = os.path.join(BASE_DIR, "history")
os.makedirs(HISTORY_DIR, exist_ok=True)

HISTORY_CSV = os.path.join(HISTORY_DIR, "predictions.csv")

# ─────────────────────────────────────────────────────────────
# CUSTOM CSS  —  dark medical theme
# ─────────────────────────────────────────────────────────────
CUSTOM_CSS = """
<style>
/* ── Google Font ────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@700&display=swap');

/* ── Root variables ─────────────────────────────────────── */
:root {
  --primary   : #4C8BF5;
  --secondary : #7C4DFF;
  --success   : #00C897;
  --warning   : #FFB347;
  --danger    : #FF5252;
  --bg-dark   : #0D1117;
  --bg-card   : #161B22;
  --bg-input  : #21262D;
  --border    : #30363D;
  --text-main : #E6EDF3;
  --text-muted: #8B949E;
}

/* ── Global ─────────────────────────────────────────────── */
html, body, [class*="css"] {
  font-family: 'Inter', sans-serif;
  background-color: var(--bg-dark) !important;
  color: var(--text-main) !important;
}

/* ── Sidebar ─────────────────────────────────────────────── */
[data-testid="stSidebar"] {
  background: linear-gradient(180deg, #0D1117 0%, #161B22 100%) !important;
  border-right: 1px solid var(--border) !important;
}
[data-testid="stSidebar"] h1,
[data-testid="stSidebar"] h2,
[data-testid="stSidebar"] h3 { color: var(--primary) !important; }

/* ── Header / Banner ─────────────────────────────────────── */
.banner {
  background: linear-gradient(135deg, #0D1117 0%, #1A1F35 50%, #0D1117 100%);
  border: 1px solid #30363D;
  border-radius: 16px;
  padding: 36px 48px;
  text-align: center;
  margin-bottom: 24px;
  position: relative;
  overflow: hidden;
}
.banner::before {
  content: "";
  position: absolute; inset: 0;
  background: radial-gradient(ellipse at 30% 50%, rgba(76,139,245,0.12) 0%, transparent 60%),
              radial-gradient(ellipse at 70% 50%, rgba(124,77,255,0.10) 0%, transparent 60%);
}
.banner h1 {
  font-family: 'Orbitron', sans-serif;
  font-size: 2.2rem !important;
  font-weight: 700;
  background: linear-gradient(90deg, #4C8BF5, #7C4DFF, #00C897);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin: 0 0 8px 0;
}
.banner p {
  color: #8B949E;
  font-size: 1rem;
  margin: 0;
}

/* ── Cards ───────────────────────────────────────────────── */  
.metric-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 20px 24px;
  text-align: center;
  transition: transform 0.2s, border-color 0.2s;
}
.metric-card:hover { transform: translateY(-3px); border-color: var(--primary); }
.metric-card .value {
  font-size: 2rem;
  font-weight: 700;
  color: var(--primary);
}
.metric-card .label {
  font-size: 0.8rem;
  color: var(--text-muted);
  margin-top: 4px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

/* ── Result box ──────────────────────────────────────────── */
.result-positive {
  background: linear-gradient(135deg, rgba(255,82,82,0.15), rgba(255,82,82,0.05));
  border: 2px solid #FF5252;
  border-radius: 16px;
  padding: 28px 32px;
  text-align: center;
  animation: fadeInUp 0.5s ease;
}
.result-negative {
  background: linear-gradient(135deg, rgba(0,200,151,0.15), rgba(0,200,151,0.05));
  border: 2px solid #00C897;
  border-radius: 16px;
  padding: 28px 32px;
  text-align: center;
  animation: fadeInUp 0.5s ease;
}
.result-title { font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; }
.result-subtitle { font-size: 0.9rem; color: var(--text-muted); }

/* ── Section headings ────────────────────────────────────── */
.section-title {
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--primary);
  border-left: 3px solid var(--primary);
  padding-left: 10px;
  margin-bottom: 16px;
}

/* ── Tab styling ─────────────────────────────────────────── */
button[kind="tab"] {
  font-weight: 600 !important;
  color: var(--text-muted) !important;
}
button[kind="tab"][aria-selected="true"] {
  color: var(--primary) !important;
  border-bottom: 2px solid var(--primary) !important;
}

/* ── Inputs ──────────────────────────────────────────────── */
input[type="number"], .stNumberInput input {
  background-color: var(--bg-input) !important;
  border: 1px solid var(--border) !important;
  color: var(--text-main) !important;
  border-radius: 8px !important;
}

/* ── Buttons ─────────────────────────────────────────────── */
.stButton button {
  background: linear-gradient(135deg, #4C8BF5, #7C4DFF) !important;
  color: white !important;
  border: none !important;
  border-radius: 10px !important;
  font-weight: 600 !important;
  padding: 0.6rem 2rem !important;
  font-size: 1rem !important;
  transition: opacity 0.2s, transform 0.1s !important;
  width: 100% !important;
}
.stButton button:hover {
  opacity: 0.9 !important;
  transform: translateY(-1px) !important;
}

/* ── Animations ──────────────────────────────────────────── */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.7; }
}

/* ── Divider ─────────────────────────────────────────────── */
hr { border-color: var(--border) !important; }

/* ── DataFrame ───────────────────────────────────────────── */
[data-testid="stDataFrame"] { border-radius: 10px; overflow: hidden; }

/* ── Spinner ─────────────────────────────────────────────── */
.stSpinner > div { border-top-color: var(--primary) !important; }

/* ── Tooltip chip ────────────────────────────────────────── */
.chip {
  display: inline-block;
  padding: 3px 10px;
  border-radius: 20px;
  font-size: 0.75rem;
  font-weight: 600;
  margin: 2px;
}
.chip-blue   { background: rgba(76,139,245,0.2); color: #4C8BF5; border: 1px solid #4C8BF5; }
.chip-green  { background: rgba(0,200,151,0.2);  color: #00C897; border: 1px solid #00C897; }
.chip-red    { background: rgba(255,82,82,0.2);  color: #FF5252; border: 1px solid #FF5252; }
.chip-yellow { background: rgba(255,179,71,0.2); color: #FFB347; border: 1px solid #FFB347; }

/* ── Info cards in sidebar ───────────────────────────────── */
.info-box {
  background: rgba(76,139,245,0.08);
  border: 1px solid rgba(76,139,245,0.3);
  border-radius: 10px;
  padding: 12px 16px;
  margin-top: 16px;
  font-size: 0.85rem;
  color: #8B949E;
}
</style>
"""

st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────
# MODEL LOADER
# ─────────────────────────────────────────────────────────────
@st.cache_resource
def load_model(disease):
    """Load saved model, scaler, imputer, and feature list."""
    model_path   = os.path.join(MODEL_DIR,  f"{disease}_model.pkl")
    scaler_path  = os.path.join(SCALER_DIR, f"{disease}_scaler.pkl")
    imputer_path = os.path.join(SCALER_DIR, f"{disease}_imputer.pkl")
    feat_path    = os.path.join(MODEL_DIR,  f"{disease}_features.pkl")

    if not os.path.exists(model_path):
        return None, None, None, None

    model    = joblib.load(model_path)
    scaler   = joblib.load(scaler_path)
    imputer  = joblib.load(imputer_path)
    features = joblib.load(feat_path)
    return model, scaler, imputer, features


@st.cache_data
def load_results(disease):
    path = os.path.join(MODEL_DIR, f"{disease}_results.csv")
    if os.path.exists(path):
        return pd.read_csv(path, index_col=0)
    return None


@st.cache_data
def load_dataset(disease):
    target = "Outcome" if disease == "diabetes" else "target"
    path   = os.path.join(DATA_DIR, f"{disease}.csv")
    if os.path.exists(path):
        return pd.read_csv(path), target
    return None, target


# ─────────────────────────────────────────────────────────────
# HISTORY HELPERS
# ─────────────────────────────────────────────────────────────
def save_prediction(disease, inputs, result, probability):
    row = {
        "timestamp"  : datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "disease"    : disease,
        "result"     : "Positive" if result == 1 else "Negative",
        "confidence" : f"{probability:.1f}%",
    }
    row.update(inputs)
    new_df = pd.DataFrame([row])
    if os.path.exists(HISTORY_CSV):
        existing = pd.read_csv(HISTORY_CSV)
        pd.concat([existing, new_df], ignore_index=True).to_csv(HISTORY_CSV, index=False)
    else:
        new_df.to_csv(HISTORY_CSV, index=False)


def load_history():
    if os.path.exists(HISTORY_CSV):
        return pd.read_csv(HISTORY_CSV)
    return pd.DataFrame()


# ─────────────────────────────────────────────────────────────
# PLOTLY THEME
# ─────────────────────────────────────────────────────────────
PLOTLY_LAYOUT = dict(
    paper_bgcolor = "#161B22",
    plot_bgcolor  = "#0D1117",
    font          = dict(color="#E6EDF3", family="Inter"),
    margin        = dict(l=40, r=20, t=50, b=40),
)

# Axis defaults to apply via update_xaxes / update_yaxes
AXIS_STYLE = dict(gridcolor="#21262D", linecolor="#30363D")

COLORS = ["#4C8BF5", "#F55C5C", "#50C878", "#FFA500"]


# ─────────────────────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="text-align:center; padding: 10px 0 20px 0;">
      <span style="font-size:3rem;">🩺</span>
      <h2 style="margin:6px 0 0 0; font-family:'Orbitron',sans-serif;
                 background:linear-gradient(90deg,#4C8BF5,#7C4DFF);
                 -webkit-background-clip:text; -webkit-text-fill-color:transparent;">
        MedAI
      </h2>
      <p style="color:#8B949E; font-size:0.8rem; margin:0;">
        Medical Diagnosis Support System
      </p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # Navigation
    page = st.selectbox(
        "🧭 Navigate",
        ["🏠 Home", "🔬 Predict", "📊 Analytics", "📋 History", "📄 About"],
        label_visibility="collapsed"
    )

    st.markdown("---")

    # Disease selector (shown on Predict page)
    disease_choice = st.radio(
        "Select Disease",
        ["🩸 Diabetes", "❤️ Heart Disease"],
        index=0
    )
    disease_key = "diabetes" if "Diabetes" in disease_choice else "heart"

    st.markdown("""
    <div class="info-box">
      ⚠️ <strong>Disclaimer</strong><br>
      This tool is for educational purposes only and does not constitute medical advice.
      Always consult a licensed healthcare professional.
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="info-box" style="margin-top:10px;">
      🔧 <strong>Model Info</strong><br>
      Algorithm: Random Forest<br>
      Datasets: Pima Indians Diabetes &amp; UCI Heart Disease
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# PAGE: HOME
# ─────────────────────────────────────────────────────────────
if page == "🏠 Home":
    st.markdown("""
    <div class="banner">
      <h1>🩺 MedAI — Disease Detection System</h1>
      <p>AI-Powered Early Disease Detection using Machine Learning &amp; Patient Health Data</p>
    </div>
    """, unsafe_allow_html=True)

    # Stats row
    col1, col2, col3, col4 = st.columns(4)
    stats = [
        ("2", "Diseases Detected"),
        ("4", "ML Algorithms"),
        ("1500+", "Training Samples"),
        ("13", "Health Features"),
    ]
    for col, (val, lbl) in zip([col1, col2, col3, col4], stats):
        col.markdown(f"""
        <div class="metric-card">
          <div class="value">{val}</div>
          <div class="label">{lbl}</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Two info columns
    left, right = st.columns(2)

    with left:
        st.markdown('<div class="section-title">📌 Problem Statement</div>', unsafe_allow_html=True)
        st.markdown("""
        Cardiovascular disease and diabetes are among the leading causes of global mortality.
        Early diagnosis significantly improves patient outcomes, yet many regions lack
        specialist access. This system leverages machine learning to provide rapid,
        data-driven risk assessments based on routine health metrics.
        """)

        st.markdown('<div class="section-title">🎯 Objectives</div>', unsafe_allow_html=True)
        objectives = [
            "Train & compare multiple ML classifiers",
            "Preprocess real medical datasets (handle missing values, normalize)",
            "Provide instant disease risk prediction with confidence score",
            "Visualize model performance and feature importance",
            "Maintain a searchable prediction history log",
        ]
        for obj in objectives:
            st.markdown(f"✅ {obj}")

    with right:
        st.markdown('<div class="section-title">🧠 ML Algorithms Used</div>', unsafe_allow_html=True)
        algorithms = {
            "Logistic Regression": ("Simple, interpretable baseline. Works well when features are linearly separable.", "chip-blue"),
            "Random Forest"      : ("Ensemble of decision trees. Handles non-linearity, reduces overfitting. Best performer.", "chip-green"),
            "SVM (RBF Kernel)"   : ("Finds optimal margin hyperplane. Excellent for high-dimensional spaces.", "chip-yellow"),
            "K-Nearest Neighbors": ("Instance-based learning. Uses proximity of similar patient records.", "chip-red"),
        }
        for name, (desc, chip) in algorithms.items():
            st.markdown(f"""
            <div style="background:#161B22; border:1px solid #30363D; border-radius:10px;
                        padding:12px 16px; margin-bottom:10px;">
              <span class="chip {chip}">{name}</span>
              <p style="margin:6px 0 0 0; font-size:0.85rem; color:#8B949E;">{desc}</p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")

    st.markdown('<div class="section-title">📊 Supported Datasets</div>', unsafe_allow_html=True)
    col_a, col_b = st.columns(2)

    with col_a:
        st.markdown("""
        <div style="background:#161B22; border:1px solid #30363D; border-radius:12px; padding:20px;">
          <h4 style="color:#4C8BF5; margin-top:0;">🩸 Pima Indians Diabetes Dataset</h4>
          <table style="width:100%; font-size:0.85rem; color:#8B949E; border-collapse:collapse;">
            <tr><td><b style="color:#E6EDF3;">Pregnancies</b></td><td>Number of pregnancies</td></tr>
            <tr><td><b style="color:#E6EDF3;">Glucose</b></td><td>Plasma glucose concentration</td></tr>
            <tr><td><b style="color:#E6EDF3;">BloodPressure</b></td><td>Diastolic BP (mm Hg)</td></tr>
            <tr><td><b style="color:#E6EDF3;">SkinThickness</b></td><td>Triceps skin fold (mm)</td></tr>
            <tr><td><b style="color:#E6EDF3;">Insulin</b></td><td>2-hour serum insulin (μU/mL)</td></tr>
            <tr><td><b style="color:#E6EDF3;">BMI</b></td><td>Body Mass Index</td></tr>
            <tr><td><b style="color:#E6EDF3;">DiabetesPedigree</b></td><td>Genetic risk function</td></tr>
            <tr><td><b style="color:#E6EDF3;">Age</b></td><td>Patient age (years)</td></tr>
            <tr><td><b style="color:#E6EDF3;">Outcome</b></td><td>1 = Diabetic, 0 = Healthy</td></tr>
          </table>
          <p style="margin:12px 0 0 0; font-size:0.75rem; color:#4C8BF5;">
            🔗 Source: UCI ML Repository / Kaggle
          </p>
        </div>
        """, unsafe_allow_html=True)

    with col_b:
        st.markdown("""
        <div style="background:#161B22; border:1px solid #30363D; border-radius:12px; padding:20px;">
          <h4 style="color:#F55C5C; margin-top:0;">❤️ UCI Heart Disease Dataset</h4>
          <table style="width:100%; font-size:0.85rem; color:#8B949E; border-collapse:collapse;">
            <tr><td><b style="color:#E6EDF3;">age</b></td><td>Patient age in years</td></tr>
            <tr><td><b style="color:#E6EDF3;">sex</b></td><td>1 = Male, 0 = Female</td></tr>
            <tr><td><b style="color:#E6EDF3;">cp</b></td><td>Chest pain type (0–3)</td></tr>
            <tr><td><b style="color:#E6EDF3;">trestbps</b></td><td>Resting blood pressure</td></tr>
            <tr><td><b style="color:#E6EDF3;">chol</b></td><td>Serum cholesterol (mg/dL)</td></tr>
            <tr><td><b style="color:#E6EDF3;">fbs</b></td><td>Fasting blood sugar &gt; 120 mg/dL</td></tr>
            <tr><td><b style="color:#E6EDF3;">thalach</b></td><td>Max heart rate achieved</td></tr>
            <tr><td><b style="color:#E6EDF3;">exang</b></td><td>Exercise induced angina</td></tr>
            <tr><td><b style="color:#E6EDF3;">oldpeak</b></td><td>ST depression by exercise</td></tr>
            <tr><td><b style="color:#E6EDF3;">target</b></td><td>1 = Disease, 0 = Healthy</td></tr>
          </table>
          <p style="margin:12px 0 0 0; font-size:0.75rem; color:#F55C5C;">
            🔗 Source: UCI ML Repository / Kaggle
          </p>
        </div>
        """, unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# PAGE: PREDICT
# ─────────────────────────────────────────────────────────────
elif page == "🔬 Predict":

    # ── Header ────────────────────────────────────────────────
    disease_label = "Diabetes" if disease_key == "diabetes" else "Heart Disease"
    icon          = "🩸" if disease_key == "diabetes" else "❤️"

    st.markdown(f"""
    <div style="background:#161B22; border:1px solid #30363D; border-radius:14px;
                padding:24px 32px; margin-bottom:24px;">
      <h2 style="margin:0; font-size:1.6rem;">
        {icon} {disease_label} — Risk Prediction
      </h2>
      <p style="color:#8B949E; margin:6px 0 0 0; font-size:0.9rem;">
        Fill in the patient's health metrics below and click <b>Predict</b>.
      </p>
    </div>
    """, unsafe_allow_html=True)

    # ── Load model ────────────────────────────────────────────
    model, scaler, imputer, features = load_model(disease_key)
    if model is None:
        st.error("⚠️ Model not found. Please run **train_models.py** first.")
        st.code("python train_models.py", language="bash")
        st.stop()

    # ── Input form ────────────────────────────────────────────
    if disease_key == "diabetes":
        st.markdown('<div class="section-title">Patient Health Metrics — Diabetes</div>', unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        with c1:
            pregnancies  = st.number_input("Pregnancies",             min_value=0,   max_value=20,  value=1,     step=1,   help="Number of times pregnant")
            skin_thick   = st.number_input("Skin Thickness (mm)",     min_value=0,   max_value=100, value=20,    step=1,   help="Triceps skin fold thickness")
            dpf          = st.number_input("Diabetes Pedigree Fxn",   min_value=0.0, max_value=3.0, value=0.47,  step=0.01,help="Genetic diabetes likelihood")
        with c2:
            glucose      = st.number_input("Glucose (mg/dL)",         min_value=0,   max_value=300, value=120,   step=1,   help="Plasma glucose concentration")
            insulin      = st.number_input("Insulin (μU/mL)",         min_value=0,   max_value=900, value=80,    step=5,   help="2-Hour serum insulin")
            age          = st.number_input("Age (years)",              min_value=1,   max_value=120, value=33,    step=1)
        with c3:
            blood_press  = st.number_input("Blood Pressure (mm Hg)",  min_value=0,   max_value=150, value=70,    step=1,   help="Diastolic blood pressure")
            bmi          = st.number_input("BMI",                      min_value=0.0, max_value=70.0,value=32.0, step=0.1, help="Body Mass Index")

        inputs_dict = {
            "Pregnancies": pregnancies, "Glucose": glucose,
            "BloodPressure": blood_press, "SkinThickness": skin_thick,
            "Insulin": insulin, "BMI": bmi,
            "DiabetesPedigreeFunction": dpf, "Age": age,
        }
        input_array = np.array([[inputs_dict[f] for f in features]])

    else:  # heart
        st.markdown('<div class="section-title">Patient Health Metrics — Heart Disease</div>', unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        with c1:
            age_h      = st.number_input("Age (years)",              min_value=20,  max_value=100, value=54,    step=1)
            sex_h      = st.selectbox("Sex",                         ["Male (1)", "Female (0)"],   index=0)
            cp_h       = st.selectbox("Chest Pain Type",             ["Typical Angina (0)", "Atypical Angina (1)", "Non-Anginal Pain (2)", "Asymptomatic (3)"], index=2)
            trestbps_h = st.number_input("Resting BP (mm Hg)",      min_value=80,  max_value=220, value=130,   step=1)
            chol_h     = st.number_input("Cholesterol (mg/dL)",     min_value=100, max_value=600, value=246,   step=5)
        with c2:
            fbs_h      = st.selectbox("Fasting Blood Sugar > 120",  ["No (0)", "Yes (1)"],         index=0)
            restecg_h  = st.selectbox("Rest. ECG Results",          ["Normal (0)", "ST-T Abnormality (1)", "LV Hypertrophy (2)"], index=0)
            thalach_h  = st.number_input("Max Heart Rate (bpm)",    min_value=60,  max_value=220, value=150,   step=1)
            exang_h    = st.selectbox("Exercise Induced Angina",    ["No (0)", "Yes (1)"],          index=0)
        with c3:
            oldpeak_h  = st.number_input("ST Depression (oldpeak)", min_value=0.0, max_value=8.0,  value=1.0,  step=0.1)
            slope_h    = st.selectbox("Slope of Peak ST Segment",   ["Upsloping (0)", "Flat (1)", "Downsloping (2)"], index=1)
            ca_h       = st.number_input("Major Vessels (0–3)",     min_value=0,   max_value=3,    value=0,    step=1)
            thal_h     = st.selectbox("Thalassemia",                ["Normal (0)", "Fixed Defect (1)", "Reversible Defect (2)", "Unknown (3)"], index=2)

        def extract_num(s): return int(s.split("(")[1].rstrip(")"))

        inputs_dict = {
            "age": age_h, "sex": extract_num(sex_h),
            "cp": extract_num(cp_h), "trestbps": trestbps_h,
            "chol": chol_h, "fbs": extract_num(fbs_h),
            "restecg": extract_num(restecg_h), "thalach": thalach_h,
            "exang": extract_num(exang_h), "oldpeak": oldpeak_h,
            "slope": extract_num(slope_h), "ca": ca_h,
            "thal": extract_num(thal_h),
        }
        input_array = np.array([[inputs_dict[f] for f in features]])

    # ── Validate & Predict ────────────────────────────────────
    st.markdown("<br>", unsafe_allow_html=True)
    col_btn, _ = st.columns([1, 3])
    with col_btn:
        predict_btn = st.button("🔮 Run Prediction", use_container_width=True)

    if predict_btn:
        with st.spinner("Analysing patient data …"):
            import time; time.sleep(0.6)  # dramatic pause
            input_imputed = imputer.transform(input_array)
            input_scaled  = scaler.transform(input_imputed)
            prediction    = model.predict(input_scaled)[0]
            probability   = model.predict_proba(input_scaled)[0][1] * 100

        st.markdown("<br>", unsafe_allow_html=True)
        res_col, gauge_col = st.columns([1, 1])

        with res_col:
            if prediction == 1:
                risk_level = "High Risk" if probability >= 70 else "Moderate Risk"
                st.markdown(f"""
                <div class="result-positive">
                  <div class="result-title" style="color:#FF5252;">⚠️ {disease_label} Detected</div>
                  <div style="font-size:2.5rem; font-weight:700; color:#FF5252; margin:12px 0;">
                    {probability:.1f}%
                  </div>
                  <div class="result-subtitle">Confidence · {risk_level}</div>
                  <hr style="border-color:#FF525240; margin:16px 0;">
                  <p style="color:#8B949E; font-size:0.85rem; margin:0;">
                    Consult a healthcare professional for clinical evaluation.
                  </p>
                </div>
                """, unsafe_allow_html=True)
            else:
                risk_level = "Low Risk"
                st.markdown(f"""
                <div class="result-negative">
                  <div class="result-title" style="color:#00C897;">✅ No {disease_label} Detected</div>
                  <div style="font-size:2.5rem; font-weight:700; color:#00C897; margin:12px 0;">
                    {100 - probability:.1f}%
                  </div>
                  <div class="result-subtitle">Confidence · {risk_level}</div>
                  <hr style="border-color:#00C89740; margin:16px 0;">
                  <p style="color:#8B949E; font-size:0.85rem; margin:0;">
                    Maintain healthy lifestyle habits and regular check-ups.
                  </p>
                </div>
                """, unsafe_allow_html=True)

        with gauge_col:
            # Gauge chart
            fig = go.Figure(go.Indicator(
                mode  = "gauge+number+delta",
                value = probability,
                number= {"suffix": "%", "font": {"size": 40, "color": "#E6EDF3"}},
                delta = {"reference": 50, "increasing": {"color": "#FF5252"},
                         "decreasing": {"color": "#00C897"}},
                gauge = {
                    "axis"    : {"range": [0, 100], "tickwidth": 1, "tickcolor": "#30363D"},
                    "bar"     : {"color": "#FF5252" if prediction == 1 else "#00C897", "thickness": 0.3},
                    "bgcolor" : "#161B22",
                    "borderwidth": 0,
                    "steps"   : [
                        {"range": [0, 40],  "color": "rgba(0,200,151,0.2)"},
                        {"range": [40, 70], "color": "rgba(255,179,71,0.2)"},
                        {"range": [70, 100],"color": "rgba(255,82,82,0.2)"},
                    ],
                    "threshold": {"line": {"color": "#E6EDF3", "width": 2},
                                  "thickness": 0.75, "value": probability},
                },
                title = {"text": "Disease Probability", "font": {"color": "#8B949E", "size": 14}},
            ))
            fig.update_layout(
                paper_bgcolor="#161B22", font_color="#E6EDF3",
                height=280, margin=dict(l=30, r=30, t=30, b=0)
            )
            st.plotly_chart(fig, use_container_width=True)

        # ── Input Summary Table ────────────────────────────────
        st.markdown('<div class="section-title" style="margin-top:20px;">📋 Input Summary</div>', unsafe_allow_html=True)
        summary_df = pd.DataFrame(
            list(inputs_dict.items()), columns=["Feature", "Value"]
        )
        st.dataframe(summary_df, use_container_width=True, hide_index=True)

        # ── Save to history ────────────────────────────────────
        save_prediction(disease_label, inputs_dict, prediction, probability)
        st.success("✅ Prediction saved to history.")


# ─────────────────────────────────────────────────────────────
# PAGE: ANALYTICS
# ─────────────────────────────────────────────────────────────
elif page == "📊 Analytics":

    st.markdown("""
    <div style="background:#161B22; border:1px solid #30363D; border-radius:14px;
                padding:24px 32px; margin-bottom:24px;">
      <h2 style="margin:0;">📊 Analytics Dashboard</h2>
      <p style="color:#8B949E; margin:6px 0 0 0;">
        Model performance metrics, ROC curves, and dataset insights.
      </p>
    </div>
    """, unsafe_allow_html=True)

    tabs = st.tabs([f"{'🩸' if disease_key == 'diabetes' else '❤️'} {disease_key.title()} Analysis",
                    "🌐 Dataset Explorer"])

    with tabs[0]:
        results_df = load_results(disease_key)
        df_data, target_col = load_dataset(disease_key)

        if results_df is None:
            st.warning("⚠️ No results found. Please run train_models.py first.")
        else:
            # ── Metrics comparison ─────────────────────────────
            st.markdown('<div class="section-title">Model Performance Comparison</div>', unsafe_allow_html=True)

            metric_cols = ["Accuracy", "Precision", "Recall", "F1 Score"]
            available   = [c for c in metric_cols if c in results_df.columns]
            plot_df     = results_df[available].copy()

            fig = go.Figure()
            for i, metric in enumerate(available):
                fig.add_trace(go.Bar(
                    name   = metric,
                    x      = list(plot_df.index),
                    y      = plot_df[metric],
                    marker_color = COLORS[i % len(COLORS)],
                    marker_line  = dict(color="#0D1117", width=1),
                ))
            fig.update_layout(
                **PLOTLY_LAYOUT,
                barmode = "group",
                title   = f"Model Comparison — {disease_key.title()}",
                height  = 380,
                legend  = dict(bgcolor="#161B22", bordercolor="#30363D", borderwidth=1),
            )
            fig.update_xaxes(**AXIS_STYLE)
            fig.update_yaxes(range=[50, 105], **AXIS_STYLE)
            st.plotly_chart(fig, use_container_width=True)

            # ── AUC-ROC ────────────────────────────────────────
            if "AUC-ROC" in results_df.columns:
                st.markdown('<div class="section-title" style="margin-top:20px;">AUC-ROC Scores</div>', unsafe_allow_html=True)
                auc_data = results_df["AUC-ROC"].sort_values(ascending=True)
                fig2 = go.Figure(go.Bar(
                    x      = auc_data.values,
                    y      = list(auc_data.index),
                    orientation = "h",
                    marker  = dict(
                        color = auc_data.values,
                        colorscale = "Bluyl",
                        cmin = 0.5, cmax = 1.0,
                    ),
                    text   = [f"{v:.4f}" for v in auc_data.values],
                    textposition = "auto",
                ))
                fig2.update_layout(
                    **PLOTLY_LAYOUT,
                    title  = "AUC-ROC by Model",
                    height = 280,
                )
                fig2.update_xaxes(range=[0.5, 1.0], **AXIS_STYLE)
                fig2.update_yaxes(**AXIS_STYLE)
                st.plotly_chart(fig2, use_container_width=True)

            # ── Full results table ──────────────────────────────
            st.markdown('<div class="section-title" style="margin-top:20px;">📐 Full Metrics Table</div>', unsafe_allow_html=True)
            display_cols = [c for c in ["Accuracy", "Precision", "Recall", "F1 Score", "AUC-ROC", "CV F1"] if c in results_df.columns]
            st.dataframe(results_df[display_cols].style.highlight_max(axis=0, color="#1E3A5F"),
                         use_container_width=True)

        # ── Feature Importance plot (png) ──────────────────────
        fi_path = os.path.join(MODEL_DIR, f"{disease_key}_feature_importance.png")
        if os.path.exists(fi_path):
            st.markdown('<div class="section-title" style="margin-top:20px;">🌟 Feature Importance (Random Forest)</div>', unsafe_allow_html=True)
            st.image(fi_path, use_container_width=True)

        # ── Confusion Matrix plot (png) ────────────────────────
        cm_path = os.path.join(MODEL_DIR, f"{disease_key}_confusion_matrix.png")
        if os.path.exists(cm_path):
            c1, c2 = st.columns([1, 1])
            with c1:
                st.markdown('<div class="section-title" style="margin-top:20px;">🧮 Confusion Matrix</div>', unsafe_allow_html=True)
                st.image(cm_path, use_container_width=True)
            roc_path = os.path.join(MODEL_DIR, f"{disease_key}_roc_curves.png")
            if os.path.exists(roc_path):
                with c2:
                    st.markdown('<div class="section-title" style="margin-top:20px;">📈 ROC Curves</div>', unsafe_allow_html=True)
                    st.image(roc_path, use_container_width=True)

    with tabs[1]:
        df_data, target_col = load_dataset(disease_key)
        if df_data is None:
            st.warning("Dataset CSV not found.")
        else:
            st.markdown(f"**{len(df_data)} rows × {len(df_data.columns)} columns**")

            # Class distribution
            col_a, col_b = st.columns(2)
            with col_a:
                st.markdown('<div class="section-title">Class Distribution</div>', unsafe_allow_html=True)
                counts = df_data[target_col].value_counts().reset_index()
                counts.columns = ["Class", "Count"]
                counts["Class"] = counts["Class"].map({0: "Healthy (0)", 1: "Positive (1)"})
                fig_pie = px.pie(
                    counts, names="Class", values="Count",
                    color_discrete_sequence=["#00C897", "#FF5252"],
                    hole=0.45,
                )
                fig_pie.update_layout(**{k: v for k, v in PLOTLY_LAYOUT.items()}, height=320)
                st.plotly_chart(fig_pie, use_container_width=True)

            with col_b:
                st.markdown('<div class="section-title">Feature Correlation Heatmap</div>', unsafe_allow_html=True)
                corr = df_data.corr(numeric_only=True)
                fig_heat = px.imshow(
                    corr, text_auto=".2f", aspect="auto",
                    color_continuous_scale="RdBu_r",
                    zmin=-1, zmax=1,
                )
                fig_heat.update_layout(**PLOTLY_LAYOUT, height=320)
                st.plotly_chart(fig_heat, use_container_width=True)

            # Feature distributions
            st.markdown('<div class="section-title" style="margin-top:8px;">Feature Distributions</div>', unsafe_allow_html=True)
            numeric_cols = df_data.select_dtypes(include=np.number).columns.tolist()
            selected_feat = st.selectbox("Select Feature", [c for c in numeric_cols if c != target_col])

            fig_dist = px.histogram(
                df_data, x=selected_feat, color=target_col,
                barmode="overlay", nbins=30,
                color_discrete_map={0: "#00C897", 1: "#FF5252"},
                labels={target_col: "Outcome"},
                opacity=0.75,
            )
            fig_dist.update_layout(**PLOTLY_LAYOUT, title=f"Distribution of {selected_feat} by Outcome", height=320)
            fig_dist.update_xaxes(**AXIS_STYLE)
            fig_dist.update_yaxes(**AXIS_STYLE)
            st.plotly_chart(fig_dist, use_container_width=True)


# ─────────────────────────────────────────────────────────────
# PAGE: HISTORY
# ─────────────────────────────────────────────────────────────
elif page == "📋 History":

    st.markdown("""
    <div style="background:#161B22; border:1px solid #30363D; border-radius:14px;
                padding:24px 32px; margin-bottom:24px;">
      <h2 style="margin:0;">📋 Prediction History</h2>
      <p style="color:#8B949E; margin:6px 0 0 0;">
        All past patient predictions are logged here automatically.
      </p>
    </div>
    """, unsafe_allow_html=True)

    history = load_history()

    if history.empty:
        st.info("No predictions yet. Go to the 🔬 Predict page to make your first prediction.")
    else:
        # Summary metrics
        total   = len(history)
        pos     = (history["result"] == "Positive").sum()
        neg     = total - pos

        mc1, mc2, mc3 = st.columns(3)
        mc1.markdown(f'<div class="metric-card"><div class="value">{total}</div><div class="label">Total Predictions</div></div>', unsafe_allow_html=True)
        mc2.markdown(f'<div class="metric-card"><div class="value" style="color:#FF5252;">{pos}</div><div class="label">Positive Cases</div></div>', unsafe_allow_html=True)
        mc3.markdown(f'<div class="metric-card"><div class="value" style="color:#00C897;">{neg}</div><div class="label">Negative Cases</div></div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Filters
        f1, f2 = st.columns([1, 3])
        with f1:
            disease_filter = st.selectbox("Filter by Disease", ["All"] + list(history["disease"].unique()))
        with f2:
            result_filter = st.radio("Filter by Result", ["All", "Positive", "Negative"], horizontal=True)

        display = history.copy()
        if disease_filter != "All":
            display = display[display["disease"] == disease_filter]
        if result_filter != "All":
            display = display[display["result"] == result_filter]

        # Colour-code result column
        def highlight_result(row):
            color = "rgba(255,82,82,0.15)" if row["result"] == "Positive" else "rgba(0,200,151,0.15)"
            return [f"background-color: {color}" if col == "result" else "" for col in row.index]

        base_cols = ["timestamp", "disease", "result", "confidence"]
        show_cols = [c for c in base_cols if c in display.columns]
        st.dataframe(
            display[show_cols].sort_values("timestamp", ascending=False).reset_index(drop=True),
            use_container_width=True,
            hide_index=True,
        )

        # Timeline chart
        if "timestamp" in display.columns and len(display) > 1:
            st.markdown('<div class="section-title" style="margin-top:20px;">📅 Prediction Timeline</div>', unsafe_allow_html=True)
            timeline = display.copy()
            timeline["timestamp"] = pd.to_datetime(timeline["timestamp"])
            timeline["date"] = timeline["timestamp"].dt.date
            daily = timeline.groupby(["date", "result"]).size().reset_index(name="count")
            fig_t = px.bar(daily, x="date", y="count", color="result",
                           color_discrete_map={"Positive": "#FF5252", "Negative": "#00C897"},
                           barmode="group")
            fig_t.update_layout(**PLOTLY_LAYOUT, title="Daily Prediction Volume", height=300)
            fig_t.update_xaxes(**AXIS_STYLE)
            fig_t.update_yaxes(**AXIS_STYLE)
            st.plotly_chart(fig_t, use_container_width=True)

        # Download
        csv_bytes = display.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download History CSV", csv_bytes, "prediction_history.csv", "text/csv")

        if st.button("🗑️ Clear History"):
            os.remove(HISTORY_CSV)
            st.rerun()


# ─────────────────────────────────────────────────────────────
# PAGE: ABOUT
# ─────────────────────────────────────────────────────────────
elif page == "📄 About":

    st.markdown("""
    <div class="banner">
      <h1>📄 About this Project</h1>
      <p>Disease Detection &amp; Medical Diagnosis Support System</p>
    </div>
    """, unsafe_allow_html=True)

    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown('<div class="section-title">🛠️ Tech Stack</div>', unsafe_allow_html=True)
        stack_items = [
            ("Python 3.x", "Core programming language"),
            ("Scikit-learn", "ML model training & evaluation"),
            ("Pandas / NumPy", "Data manipulation & preprocessing"),
            ("Streamlit", "Interactive web dashboard"),
            ("Plotly", "Interactive charts & visualizations"),
            ("Matplotlib / Seaborn", "Static plot generation"),
            ("Joblib", "Model serialization (.pkl files)"),
        ]
        for tech, desc in stack_items:
            st.markdown(f"""
            <div style="display:flex; align-items:center; gap:10px; padding:8px 0;
                        border-bottom:1px solid #21262D;">
              <span class="chip chip-blue">{tech}</span>
              <span style="color:#8B949E; font-size:0.85rem;">{desc}</span>
            </div>
            """, unsafe_allow_html=True)

    with col_right:
        st.markdown('<div class="section-title">📐 Preprocessing Pipeline</div>', unsafe_allow_html=True)
        steps = [
            ("1", "Load Dataset", "CSV → Pandas DataFrame"),
            ("2", "Handle Missing Values", "Replace 0s with NaN, impute with median"),
            ("3", "Train-Test Split", "80% train / 20% test, stratified"),
            ("4", "Normalization", "StandardScaler (z-score normalization)"),
            ("5", "Model Training", "4 classifiers with StratifiedKFold CV"),
            ("6", "Evaluation", "Accuracy, Precision, Recall, F1, AUC-ROC"),
            ("7", "Model Selection", "Best F1 score → serialize to .pkl"),
        ]
        for num, title, detail in steps:
            st.markdown(f"""
            <div style="display:flex; gap:12px; align-items:flex-start; margin-bottom:12px;">
              <div style="background:linear-gradient(135deg,#4C8BF5,#7C4DFF); color:white;
                          border-radius:50%; width:28px; height:28px; min-width:28px;
                          display:flex; align-items:center; justify-content:center;
                          font-weight:700; font-size:0.8rem;">{num}</div>
              <div>
                <div style="font-weight:600; font-size:0.9rem;">{title}</div>
                <div style="color:#8B949E; font-size:0.8rem;">{detail}</div>
              </div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")

    # Algorithm comparison table
    st.markdown('<div class="section-title">🤖 Algorithm Comparison</div>', unsafe_allow_html=True)
    algo_data = {
        "Algorithm"       : ["Logistic Regression", "Random Forest", "SVM (RBF)", "KNN"],
        "Type"            : ["Linear Classifier", "Ensemble (Bagging)", "Kernel Method", "Instance-Based"],
        "Strengths"       : ["Fast, interpretable", "High accuracy, robust", "Good on small datasets", "No training phase"],
        "Weaknesses"      : ["Assumes linearity", "Slower to predict", "Slow on large data", "Sensitive to scale"],
        "Best For"        : ["Baseline comparison", "Final deployment", "Complex boundaries", "Low-latency demos"],
    }
    st.dataframe(pd.DataFrame(algo_data), use_container_width=True, hide_index=True)

    st.markdown("---")

    # Dataset sources
    st.markdown('<div class="section-title">📦 Dataset Sources</div>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("""
        **🩸 Pima Indians Diabetes Dataset**
        - **Source**: UCI Machine Learning Repository
        - **URL**: [Kaggle Link](https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database)
        - **Size**: 768 rows, 8 features
        - **Target**: `Outcome` (0 = No Diabetes, 1 = Diabetes)
        - **Note**: Biologically impossible zeros treated as missing
        """)
    with c2:
        st.markdown("""
        **❤️ UCI Heart Disease (Cleveland) Dataset**
        - **Source**: UCI Machine Learning Repository
        - **URL**: [Kaggle Link](https://www.kaggle.com/datasets/johnsmith88/heart-disease-dataset)
        - **Size**: 303 rows, 13 features
        - **Target**: `target` (0 = No Disease, 1 = Heart Disease)
        - **Note**: Multi-class target binarized to 0/1
        """)

    st.markdown("---")
    st.markdown("""
    <div style="text-align:center; color:#8B949E; font-size:0.85rem; padding:20px 0;">
      Built with ❤️ for college submission · MedAI Disease Detection System v1.0<br>
      <span style="color:#4C8BF5;">Intermediate ML Project — Python · Scikit-learn · Streamlit</span>
    </div>
    """, unsafe_allow_html=True)
