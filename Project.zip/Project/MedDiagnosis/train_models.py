"""
================================================================
 Disease Detection & Medical Diagnosis Support System
 train_models.py  --  ML Training Pipeline
================================================================
 Datasets  : Pima Indians Diabetes  |  UCI Heart Disease
 Algorithms: Logistic Regression, Random Forest, SVM, KNN
 Output    : Saved .pkl model files in models/ directory
================================================================
"""

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")            # headless backend for saving figures
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectKBest, f_classif

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier

from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report,
    roc_auc_score, roc_curve, f1_score
)

warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────────
# 1. PATHS
# ─────────────────────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
DATA_DIR   = os.path.join(BASE_DIR, "datasets")
MODEL_DIR  = os.path.join(BASE_DIR, "models")
SCALER_DIR = os.path.join(MODEL_DIR, "scalers")

for d in [DATA_DIR, MODEL_DIR, SCALER_DIR]:
    os.makedirs(d, exist_ok=True)


# ─────────────────────────────────────────────────────────────
# 2. DATASET GENERATORS  (synthetic fallback if CSVs missing)
# ─────────────────────────────────────────────────────────────
def generate_diabetes_data():
    """
    Generates a realistic synthetic Diabetes dataset
    modelled on the Pima Indians Diabetes dataset.
    In production, replace with the real CSV from:
    https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database
    """
    np.random.seed(42)
    n = 800
    df = pd.DataFrame({
        "Pregnancies"             : np.random.randint(0, 18, n),
        "Glucose"                 : np.clip(np.random.normal(121, 32, n), 0, 200).astype(int),
        "BloodPressure"           : np.clip(np.random.normal(69, 19, n), 0, 122).astype(int),
        "SkinThickness"           : np.clip(np.random.normal(20, 16, n), 0, 99).astype(int),
        "Insulin"                 : np.clip(np.random.exponential(70, n), 0, 846).astype(int),
        "BMI"                     : np.round(np.clip(np.random.normal(32, 7, n), 0, 67), 1),
        "DiabetesPedigreeFunction": np.round(np.clip(np.random.exponential(0.47, n), 0.08, 2.42), 3),
        "Age"                     : np.clip(np.random.randint(21, 82, n), 21, 81),
    })
    # Outcome influenced by Glucose + BMI + Age
    score = (
        0.04 * df["Glucose"]
        + 0.06 * df["BMI"]
        + 0.01 * df["Age"]
        + 0.05 * df["Pregnancies"]
        - 4.5
        + np.random.normal(0, 0.8, n)
    )
    df["Outcome"] = (score > 0).astype(int)
    return df


def generate_heart_data():
    """
    Generates a realistic synthetic Heart Disease dataset
    modelled on the Cleveland UCI Heart Disease dataset.
    In production, replace with the real CSV from:
    https://www.kaggle.com/datasets/johnsmith88/heart-disease-dataset
    """
    np.random.seed(7)
    n = 700
    age  = np.random.randint(29, 78, n)
    sex  = np.random.randint(0, 2, n)
    cp   = np.random.randint(0, 4, n)
    trestbps = np.clip(np.random.normal(131, 18, n), 94, 200).astype(int)
    chol     = np.clip(np.random.normal(246, 52, n), 126, 564).astype(int)
    fbs      = (np.random.random(n) > 0.85).astype(int)
    restecg  = np.random.randint(0, 3, n)
    thalach  = np.clip(np.random.normal(150, 23, n), 71, 202).astype(int)
    exang    = np.random.randint(0, 2, n)
    oldpeak  = np.round(np.clip(np.random.exponential(1.1, n), 0, 6.2), 1)
    slope    = np.random.randint(0, 3, n)
    ca       = np.random.randint(0, 4, n)
    thal     = np.random.randint(0, 4, n)

    df = pd.DataFrame({
        "age": age, "sex": sex, "cp": cp, "trestbps": trestbps,
        "chol": chol, "fbs": fbs, "restecg": restecg,
        "thalach": thalach, "exang": exang, "oldpeak": oldpeak,
        "slope": slope, "ca": ca, "thal": thal,
    })
    score = (
        0.04 * df["age"]
        + 0.03 * df["trestbps"]
        + 0.01 * df["chol"]
        - 0.03 * df["thalach"]
        + 0.3  * df["exang"]
        + 0.2  * df["cp"]
        + 0.8  * df["oldpeak"]
        - 3.0
        + np.random.normal(0, 0.9, n)
    )
    df["target"] = (score > 0).astype(int)
    return df


# ─────────────────────────────────────────────────────────────
# 3. LOAD DATASETS
# ─────────────────────────────────────────────────────────────
def load_dataset(name):
    """Load CSV if present, else generate synthetic data."""
    csv_path = os.path.join(DATA_DIR, f"{name}.csv")
    if os.path.exists(csv_path):
        print(f"  [OK] Loaded {name}.csv from disk")
        return pd.read_csv(csv_path)
    else:
        print(f"  [!] {name}.csv not found -- generating synthetic data ...")
        if name == "diabetes":
            df = generate_diabetes_data()
        else:
            df = generate_heart_data()
        df.to_csv(csv_path, index=False)
        print(f"  [OK] Saved synthetic {name}.csv to datasets/")
        return df


# ─────────────────────────────────────────────────────────────
# 4. PREPROCESSING
# ─────────────────────────────────────────────────────────────
def preprocess(df, target_col, zero_cols=None):
    """
    Steps:
      - Replace biologically impossible zeros with NaN (diabetes specific)
      - Impute missing values with column median
      - Separate features (X) and target (y)
      - Normalize with StandardScaler
    """
    df = df.copy()

    # For diabetes: 0 in medical columns = missing
    if zero_cols:
        for col in zero_cols:
            df[col] = df[col].replace(0, np.nan)

    X = df.drop(columns=[target_col])
    y = df[target_col]

    # Median imputation
    imputer = SimpleImputer(strategy="median")
    X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=X.columns)

    # Scale
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_imputed)

    return X_scaled, y.values, scaler, list(X.columns), imputer


# ─────────────────────────────────────────────────────────────
# 5. MODEL DEFINITIONS
# ─────────────────────────────────────────────────────────────
def get_models():
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Random Forest"      : RandomForestClassifier(n_estimators=200, random_state=42),
        "SVM"                : SVC(probability=True, kernel="rbf", random_state=42),
        "KNN"                : KNeighborsClassifier(n_neighbors=7),
    }


# ─────────────────────────────────────────────────────────────
# 6. TRAIN & EVALUATE
# ─────────────────────────────────────────────────────────────
def train_and_evaluate(X, y, dataset_name):
    """
    Train all classifiers, collect metrics, return best model.
    Uses Stratified 5-Fold cross-validation + holdout (80/20 split).
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    models   = get_models()
    cv       = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    results  = {}
    best_f1  = 0
    best_name = None
    best_model = None

    print(f"\n{'-'*60}")
    print(f"  Training on: {dataset_name}")
    print(f"{'-'*60}")
    print(f"  {'Model':<22} {'Acc':>7} {'Prec':>7} {'Rec':>7} {'F1':>7} {'AUC':>7}")
    print(f"  {'-'*55}")

    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]

        acc   = accuracy_score(y_test, y_pred)
        rpt   = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
        prec  = rpt["weighted avg"]["precision"]
        rec   = rpt["weighted avg"]["recall"]
        f1    = rpt["weighted avg"]["f1-score"]
        auc   = roc_auc_score(y_test, y_prob)
        cv_f1 = cross_val_score(model, X, y, cv=cv, scoring="f1_weighted").mean()

        results[name] = {
            "Accuracy" : round(acc * 100, 2),
            "Precision": round(prec * 100, 2),
            "Recall"   : round(rec * 100, 2),
            "F1 Score" : round(f1 * 100, 2),
            "AUC-ROC"  : round(auc, 4),
            "CV F1"    : round(cv_f1 * 100, 2),
            "model"    : model,
            "y_test"   : y_test,
            "y_prob"   : y_prob,
            "y_pred"   : y_pred,
        }

        print(f"  {name:<22} {acc*100:>6.2f}% {prec*100:>6.2f}% {rec*100:>6.2f}% {f1*100:>6.2f}% {auc:>7.4f}")

        if f1 > best_f1:
            best_f1   = f1
            best_name = name
            best_model = model

    print(f"\n  [BEST] Model: {best_name} (F1 = {best_f1*100:.2f}%)")
    return results, best_name, best_model, X_test, y_test


# ─────────────────────────────────────────────────────────────
# 7. SAVE ARTEFACTS
# ─────────────────────────────────────────────────────────────
def save_artefacts(model, scaler, imputer, feature_names, disease):
    """Persist model, scaler, imputer and feature list."""
    joblib.dump(model,         os.path.join(MODEL_DIR,  f"{disease}_model.pkl"))
    joblib.dump(scaler,        os.path.join(SCALER_DIR, f"{disease}_scaler.pkl"))
    joblib.dump(imputer,       os.path.join(SCALER_DIR, f"{disease}_imputer.pkl"))
    joblib.dump(feature_names, os.path.join(MODEL_DIR,  f"{disease}_features.pkl"))
    print(f"  [SAVED] {disease} model artefacts -> models/")


# ─────────────────────────────────────────────────────────────
# 8. PLOT HELPERS
# ─────────────────────────────────────────────────────────────
def plot_confusion_matrix(y_test, y_pred, model_name, disease, out_dir):
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["No Disease", "Disease"],
                yticklabels=["No Disease", "Disease"])
    ax.set_title(f"Confusion Matrix — {model_name}\n({disease})", fontsize=11, fontweight="bold")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    plt.tight_layout()
    path = os.path.join(out_dir, f"{disease}_confusion_matrix.png")
    plt.savefig(path, dpi=120)
    plt.close()
    return path


def plot_roc_curves(results, disease, out_dir):
    fig, ax = plt.subplots(figsize=(7, 5))
    colors = ["#4C8BF5", "#F55C5C", "#50C878", "#FFA500"]
    for (name, res), color in zip(results.items(), colors):
        fpr, tpr, _ = roc_curve(res["y_test"], res["y_prob"])
        ax.plot(fpr, tpr, label=f"{name} (AUC={res['AUC-ROC']:.3f})", color=color, lw=2)
    ax.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5)
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate", fontsize=11)
    ax.set_title(f"ROC Curves — {disease}", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    path = os.path.join(out_dir, f"{disease}_roc_curves.png")
    plt.savefig(path, dpi=120)
    plt.close()
    return path


def plot_model_comparison(results, disease, out_dir):
    metrics = ["Accuracy", "Precision", "Recall", "F1 Score", "AUC-ROC"]
    data = {
        name: [res[m] if m != "AUC-ROC" else res[m] * 100 for m in metrics]
        for name, res in results.items()
    }
    df_cmp = pd.DataFrame(data, index=metrics)
    fig, ax = plt.subplots(figsize=(9, 5))
    df_cmp.T.plot(kind="bar", ax=ax, colormap="Set2", edgecolor="white", width=0.7)
    ax.set_title(f"Model Comparison — {disease}", fontsize=13, fontweight="bold")
    ax.set_ylabel("Score (%)")
    ax.set_ylim(50, 105)
    ax.legend(loc="lower right", fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    plt.xticks(rotation=0)
    plt.tight_layout()
    path = os.path.join(out_dir, f"{disease}_model_comparison.png")
    plt.savefig(path, dpi=120)
    plt.close()
    return path


def plot_feature_importance(model, feature_names, disease, out_dir):
    if not hasattr(model, "feature_importances_"):
        return None
    importances = model.feature_importances_
    idx = np.argsort(importances)[::-1]
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = plt.cm.RdYlGn(np.linspace(0.3, 0.9, len(feature_names)))
    ax.barh(
        [feature_names[i] for i in idx[::-1]],
        importances[idx[::-1]],
        color=colors, edgecolor="white"
    )
    ax.set_title(f"Feature Importance — {disease} (Random Forest)", fontsize=12, fontweight="bold")
    ax.set_xlabel("Importance Score")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    path = os.path.join(out_dir, f"{disease}_feature_importance.png")
    plt.savefig(path, dpi=120)
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────
# 9. MAIN PIPELINE
# ─────────────────────────────────────────────────────────────
def pipeline(disease):
    print(f"\n{'═'*60}")
    print(f"  PIPELINE: {disease.upper()}")
    print(f"{'═'*60}")

    # ── Load ──────────────────────────────────────────────────
    df = load_dataset(disease)

    # ── Config per disease ────────────────────────────────────
    if disease == "diabetes":
        target_col = "Outcome"
        zero_cols  = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
    else:
        target_col = "target"
        zero_cols  = None

    # ── Preprocess ────────────────────────────────────────────
    X, y, scaler, feature_names, imputer = preprocess(df, target_col, zero_cols)
    print(f"  Features : {feature_names}")
    print(f"  Samples  : {len(y)}  |  Positives: {y.sum()} ({y.mean()*100:.1f}%)")

    # ── Train & Evaluate ──────────────────────────────────────
    results, best_name, best_model, X_test, y_test = train_and_evaluate(X, y, disease)

    # ── Save ──────────────────────────────────────────────────
    save_artefacts(best_model, scaler, imputer, feature_names, disease)

    # ── Plots ─────────────────────────────────────────────────
    plots_dir = os.path.join(BASE_DIR, "models")
    plot_confusion_matrix(y_test, results[best_name]["y_pred"], best_name, disease, plots_dir)
    plot_roc_curves(results, disease, plots_dir)
    plot_model_comparison(results, disease, plots_dir)
    plot_feature_importance(best_model, feature_names, disease, plots_dir)

    print(f"\n  [OK] Plots saved to models/")

    # ── Save summary CSV ──────────────────────────────────────
    summary = {
        name: {k: v for k, v in res.items()
               if k not in ("model", "y_test", "y_prob", "y_pred")}
        for name, res in results.items()
    }
    pd.DataFrame(summary).T.to_csv(
        os.path.join(MODEL_DIR, f"{disease}_results.csv")
    )
    return results


if __name__ == "__main__":
    print("\n" + "#"*60)
    print("  Disease Detection -- Model Training Pipeline")
    print("#"*60)

    pipeline("diabetes")
    pipeline("heart")

    print("\n" + "="*60)
    print("  [DONE] Training complete! Run:  streamlit run app.py")
    print("="*60 + "\n")
